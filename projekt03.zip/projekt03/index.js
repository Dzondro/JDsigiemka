import express from "express";
import bodyParser from "body-parser";
import sqlite3 from "sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 8000;


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));


const db = new sqlite3.Database("database.db");

db.run(`
  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    content TEXT,
    created_at TEXT
  )
`);

app.get("/", (req, res) => {
  db.all("SELECT * FROM posts", [], (err, rows) => {
    if (err) throw err;
    res.render("index", { posts: rows });
  });
});


app.post("/add", (req, res) => {
  const { title, content } = req.body;
  if (title && content) {
    db.run(
      "INSERT INTO posts (title, content, created_at) VALUES (?, ?, ?)",
      [title, content, new Date().toLocaleString()]
    );
  }
  res.redirect("/");
});


app.get("/edit/:id", (req, res) => {
  db.get("SELECT * FROM posts WHERE id = ?", [req.params.id], (err, post) => {
    if (err) throw err;
    res.render("edit", { post });
  });
});

app.post("/edit/:id", (req, res) => {
  const { title, content } = req.body;
  db.run(
    "UPDATE posts SET title = ?, content = ? WHERE id = ?",
    [title, content, req.params.id]
  );
  res.redirect("/");
});

app.post("/delete/:id", (req, res) => {
  db.run("DELETE FROM posts WHERE id = ?", [req.params.id]);
  res.redirect("/");
});

app.post("/seed", (req, res) => {
  const sampleData = [
    ["Pierwszy wpis", "Treść testowa 1", new Date().toLocaleString()],
    ["Drugi wpis", "Treść testowa 2", new Date().toLocaleString()],
    ["Trzeci wpis", "Treść testowa 3", new Date().toLocaleString()]
  ];

  sampleData.forEach(post => {
    db.run(
      "INSERT INTO posts (title, content, created_at) VALUES (?, ?, ?)",
      post
    );
  });

  res.redirect("/");
});

app.listen(PORT, () => {
  console.log(`Serwer działa na http://localhost:${PORT}`);
});
